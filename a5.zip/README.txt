To compile, simply call the command $make.
To run, use the command $./solver path-to-level